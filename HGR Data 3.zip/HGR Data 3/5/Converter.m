close all
clear

titles = {'1YOSHI','2YOSHI','3YOSHI','4YOSHI','5YOSHI','AYOSHI','BYOSHI','CYOSHI','DYOSHI','EYOSHI','FYOSHI','GYOSHI','HYOSHI','IYOSHI','VYOSHI','WYOSHI'...
    'XYOSHI','YYOSHI','P1HYOSHI','P1LYOSHI','P2HYOSHI','P2LYOSHI','P3HYOSHI','P3LYOSHI','P4HYOSHI','P4LYOSHI'};
tit = {'1n', '2n', '3n', '4n', '5n', 'An', 'Bn', 'Cn', 'Dn', 'En', 'Fn', 'Gn', 'Hn', 'In', ...
    'Vn', 'Wn', 'Xn', 'Yn', 'P1Hn', 'P1Ln', 'P2Hn', 'P2Ln', 'P3Hn', 'P3Ln', 'P4Hn', 'P4Ln'};
freq = 14; % 179kHz
titleLen = length(titles);
for i = 1:titleLen
    for j = 1:3
    imp = impCal(36,freq,strcat(titles{i},num2str(j)));
    imp = movmean(imp, 10, 1);                     % moving average filter
    imp = (imp - min(imp)) ./ (max(imp) - min(imp)); % normalize columns
    writematrix(imp, strcat(tit{i},num2str(j),'.csv'))
    end
end

frequencies = [1,2,3,7,11,17,23,31,43,61,89,127,179,251,349];

figure
plot(imp)
xlabel('Index')
ylabel('Impedance (Ohm)')

function dd = impCal (chNUM,fr1,tit)

data_temp = readmatrix(strcat(tit,'.txt'), 'Delimiter', '\t', 'ConsecutiveDelimitersRule', 'join');
data_temp(any(isnan(data_temp),2),:) = []; %remove rows with nan

% fr1 = 10; % 7k [idx 1k 2k 3k 7k 11k 17k 23k 31k 43k 61k 89k 127k]

re1 = data_temp(:, fr1);
im1 = data_temp(:, fr1 + 15);
mag1 = sqrt(re1.*re1 + im1.*im1);
%mag1 = re1;

ch = zeros(size(mag1(1:chNUM:end,1),1),size(mag1(1:chNUM:end,1),2),chNUM);
for i = 1:chNUM
    %figure
    %subplot(chNUM,1,i)
    ch(:,:,i) = mag1(i:chNUM:end,1);
    ch(:,:,i) = movmean(ch(:,:,i),5);
    % plot(ch(:,:,i))
    %ylim([0 60])
    % hold on
end

% hold off

dd=squeeze(ch);
end 

function snr = snrCal (temp)
    rest_mean = mean(temp,1);
    rest_std = std(temp,1);
    snr = 20*log10(rest_mean./rest_std);
end