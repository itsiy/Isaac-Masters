names = {'1n', '2n', '3n', '4n', '5n', 'An', 'Bn', 'Cn', 'Dn', 'En', 'Fn', 'Gn', 'Hn', 'In', ...
    'Vn', 'Wn', 'Xn', 'Yn', 'P1Hn', 'P1Ln', 'P2Hn', 'P2Ln', 'P3Hn', 'P3Ln', 'P4Hn', 'P4Ln'};
rounds = {'1','2','3'};
for j = 1:26
    qq = [];
    for idx = 1:3
        title = strcat(names{j},rounds{idx},'.csv');
        tempdata = readmatrix(title);
        tempdata = tempdata(1:100,:);
        qq = [qq;tempdata];
    end
    writematrix(qq,strcat(names{j},'.csv'))
end

% for j = 1:26
%     qq = [];
%         title = strcat('round5',names{j},'.csv');
%         tempdata = readmatrix(title);
%         tempdata = tempdata(1:20,:);
%         qq = [qq;tempdata];
%     writematrix(qq,strcat('testData',names{j},'.csv'))
% end