import random
import os
from PIL import Image
import matplotlib.pyplot as plt

# List of all items
items = [
    "1", "2", "3", "4", "5",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "V", "W", "X", "Y",
    "P1L", "P2L", "P3L", "P4L",
    "P1H", "P2H", "P3H", "P4H"
]

# Loop through all items
for i in range(len(items)):
    selected = random.choice(items)
    items.remove(selected)

    filename = f"{selected}.png"
    filepath = os.path.join(os.getcwd(), filename)

    try:
        img = Image.open(filepath)

        # Show using matplotlib
        plt.imshow(img)
        plt.axis('off')
        plt.title(f"{i}. Showing {filename}")
        plt.show(block=False)

        input(f"{i}. {filename} Press Enter to continue...")
        plt.close()  # This closes the matplotlib window

    except FileNotFoundError:
        print(f"File {filename} not found. Skipping...")
