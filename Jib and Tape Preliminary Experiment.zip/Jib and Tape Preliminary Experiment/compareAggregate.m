close all; clear;

%% Settings
ENABLE_OUTLIER_DETECTION = false;
EXCLUDE_OUTLIER_DATA = false;
NORMALISE_BY_PERSON = true;
OUTLIER_METHOD = "std";
STD_MULTIPLIER = 2;

%% Titles Setup
titles = ["ACGY", "ACGB", "ACGP", "ACPY", "ACPB", "ACYB", ...
          "ICGY", "ICGB", "ICGP", "ICPY", "ICPB", "ICYB", ...
          "KCGY", "KCGB", "KCGP", "KCPY", "KCPB", "KCYB", ...
          "NCGY", "NCGB", "NCGP", "NCPY", "NCPB", "NCYB", ...
          "AFGY", "AFGB", "AFGP", "AFPY", "AFPB", "AFYB", ...
          "IFGY", "IFGB", "IFGP", "IFPY", "IFPB", "IFYB", ...
          "KFGY", "KFGB", "KFGP", "KFPY", "KFPB", "KFYB", ...
          "NFGY", "NFGB", "NFGP", "NFPY", "NFPB", "NFYB", ...
          "AKGY", "AKGB", "AKGP", "AKPY", "AKPB", "AKYB", ...
          "IKGY", "IKGB", "IKGP", "IKPY", "IKPB", "IKYB", ...
          "KKGY", "KKGB", "KKGP", "KKPY", "KKPB", "KKYB", ...
          "NKGY", "NKGB", "NKGP", "NKPY", "NKPB", "NKYB", ...
          "ATGY", "ATGB", "ATGP", "ATPY", "ATPB", "ATYB", ...
          "ITGY", "ITGB", "ITGP", "ITPY", "ITPB", "ITYB", ...
          "KTGY", "KTGB", "KTGP", "KTPY", "KTPB", "KTYB", ...
          "NTGY", "NTGB", "NTGP", "NTPY", "NTPB", "NTYB", ...
          "AEGY", "AEGB", "AEGP", "AEPY", "AEPB", "AEYB", ...
          "IEGY", "IEGB", "IEGP", "IEPY", "IEPB", "IEYB", ...
          "KEGY", "KEGB", "KEGP", "KEPY", "KEPB", "KEYB", ...
          "NEGY", "NEGB", "NEGP", "NEPY", "NEPB", "NEYB"];
titleLen = length(titles);
varNumber = 5;
trialsPerVar = titleLen / varNumber;
setup_names = extractBetween(titles(1:trialsPerVar:end), 2, 2);

meanPerDesign = zeros(15, varNumber);
stdPerDesign = zeros(15, varNumber);

%% NORMALISE PER PERSON
if NORMALISE_BY_PERSON
    personIDs = extractBetween(titles, 1, 1);
    uniquePeople = unique(personIDs);

    for i = 1:length(uniquePeople)
        person = uniquePeople{i};
        personTitles = titles(startsWith(titles, person));

        allDataStack = [];
        for t = 1:length(personTitles)
            raw = readmatrix(strcat(personTitles(t), ".txt"), ...
                             "Delimiter", "\t", "NumHeaderLines", 15);
            raw = raw(1:2:end, 2:end);

            targetLen = 200;
            if size(raw, 1) > targetLen
                raw = raw(1:targetLen, :);
            elseif size(raw, 1) < targetLen
                raw = [raw; repmat(raw(end, :), targetLen - size(raw,1), 1)];
            end

            allDataStack = cat(3, allDataStack, raw);  % 200 x 30 x N
        end

        % Min/max across all samples and trials per channel
        minVal = squeeze(min(allDataStack, [], [1 3]));
        maxVal = squeeze(max(allDataStack, [], [1 3]));

        for t = 1:length(personTitles)
            raw = allDataStack(:,:,t);
            normed = (raw - minVal) ./ (maxVal - minVal + eps);
            writematrix(normed, strcat(personTitles(t), " normalised.csv"));
        end
    end
end

%% MAIN LOOP
for design = 1:varNumber
    perTrialImpedance = zeros(15, trialsPerVar);
    f = waitbar(0, sprintf('Processing Design %d/%d', design, varNumber));

    for trial = 1:trialsPerVar
        idx = trial + (design - 1) * trialsPerVar;
        waitbar(trial/trialsPerVar, f, sprintf('Trial %d/%d', trial, trialsPerVar));
        perTrialImpedance(:, trial) = getMeanImpedance(summariseCSV(titles(idx), true)); % use normalised
    end
    close(f);

    % Outlier Detection
    outlierMask = false(1, trialsPerVar);
    if ENABLE_OUTLIER_DETECTION || EXCLUDE_OUTLIER_DATA
        switch OUTLIER_METHOD
            case "std"
                impMean = mean(perTrialImpedance, 2);
                impStd = std(perTrialImpedance, 0, 2);
                upper = impMean + STD_MULTIPLIER * impStd;
                lower = impMean - STD_MULTIPLIER * impStd;
                for trial = 1:trialsPerVar
                    if any(perTrialImpedance(:, trial) > upper | perTrialImpedance(:, trial) < lower)
                        outlierMask(trial) = true;
                    end
                end
            case "zscore"
                z = abs((perTrialImpedance - mean(perTrialImpedance, 2)) ./ std(perTrialImpedance, 0, 2));
                outlierMask = any(z > 2, 1);
        end
    end

    plotAllTrials(perTrialImpedance, setup_names{design}, outlierMask, ENABLE_OUTLIER_DETECTION);
    saveas(gcf, sprintf('TrialImpedance_Design_%s.png', setup_names{design}));

    if EXCLUDE_OUTLIER_DATA
        perTrialImpedance(:, outlierMask) = [];
    end

    perDesignImpedance{design} = perTrialImpedance;
    meanPerDesign(:, design) = mean(perTrialImpedance, 2);
    stdPerDesign(:, design) = std(perTrialImpedance, 0, 2);
end

plotImpedance(meanPerDesign, stdPerDesign, varNumber, setup_names);
saveas(gcf, 'R_Impedance_Comparison.png');
compareSetups(perDesignImpedance, setup_names);

%% === Helper Functions ===

function summary = summariseCSV(title, isNormalized)
    if isNormalized
        raw = readmatrix(strcat(title, " normalised.csv"));
    else
        raw = readmatrix(strcat(title, ".csv"));
    end
    summary = zeros(15, 2);
    for i = 1:15
        realZ = raw(:, i);
        imagZ = raw(:, i + 15);
        Zmag = sqrt(realZ.^2 + imagZ.^2);
        summary(i, :) = [mean(Zmag), std(Zmag)];
    end
end

function meanImpedance = getMeanImpedance(summary)
    meanImpedance = summary(:, 1);
end

function plotAllTrials(data, setup_name, outlierMask, highlight)
    fIdx = 1:15;
    n = size(data, 2);
    cmap = turbo(n);
    figure; hold on;

    for i = 1:n
        if highlight && outlierMask(i)
            plot(fIdx, data(:,i), '--', 'Color', cmap(i,:), 'LineWidth', 2.5);
        else
            plot(fIdx, data(:,i), '-', 'Color', cmap(i,:), 'LineWidth', 1.2);
        end
    end

    ylim([0 1]);
    xlabel('Frequency Index'); ylabel('Normalised Impedance');
    title(['Normalised Impedance per Trial (', setup_name, ' Setup)']);
    legend("Trial " + string(1:n), 'Location', 'eastoutside'); grid on;
    hold off;
end

function plotImpedance(meanVals, stdVals, varNumber, setup_names)
    fIdx = 1:15;
    colors = lines(varNumber);
    figure; hold on;

    for i = 1:varNumber
        errorbar(fIdx, meanVals(:, i), stdVals(:, i), '-o', ...
            'Color', colors(i,:), 'LineWidth', 1.5, ...
            'DisplayName', setup_names{i});
    end

    ylim([0 1]);
    xlabel('Frequency Index'); ylabel('Normalised Impedance');
    title('Mean Normalised Impedance per Design ± Std Dev');
    legend('Location', 'best'); grid on;
    hold off;
end

function compareSetups(perDesignImpedance, setup_names)
    fprintf('Impedance Significance Testing: ANOVA per Frequency\n\n');
    for freqIdx = 1:15
        allData = [];
        groupLabels = [];
        for design = 1:numel(perDesignImpedance)
            if setup_names(design) == "E", continue; end
            impAtFreq = perDesignImpedance{design}(freqIdx, :);
            allData = [allData; impAtFreq(:)];
            groupLabels = [groupLabels; repmat(setup_names(design), length(impAtFreq), 1)];
        end
        [p, tbl, stats] = anova1(allData, groupLabels, 'off');
        SS_between = cell2mat(tbl(2,2));
        SS_total = cell2mat(tbl(4,2));
        etaSquared = SS_between / SS_total;
        if p < 0.05
            result = multcompare(stats, 'Display', 'off');
            sigPairs = result(result(:,6) < 0.05, :);
            fprintf('  Significant Differences Between:\n');
            for r = 1:size(sigPairs, 1)
                g1 = stats.gnames{sigPairs(r, 1)}; g2 = stats.gnames{sigPairs(r, 2)};
                diff = sigPairs(r, 4);
                fprintf('    %s vs %s (mean diff = %.4f)\n', g1, g2, diff);
            end
            fprintf('Freq %2d: Significant (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        else
            fprintf('Freq %2d: No significant difference (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        end
    end
end
