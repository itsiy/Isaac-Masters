close all
clear

titles = ["ACGB", "ACGP","ACGY","ACPB","ACPY","ACYB",...
    "CCGB", "CCGP","CCGY","CCPB","CCPY","CCYB",...
    "ICGB", "ICGP","ICGY","ICPB","ICPY","ICYB",...
    "LCGB", "LCGP","LCGY","LCPB","LCPY","LCYB",...
    "NCGB", "NCGP","NCGY","NCPB","NCPY","NCYB",...
    "AEGB", "AEGP","AEYG","AEBP","AEYP","AEYB",...
    "CEGB", "CEGP","CEGY","CEPB","CEPY","CEYB",...
    "IEGB", "IEGP","IEGY","IEPB","IEPY","IEYB",...
    "LEGB", "LEGP","LEGY","LEBP","LEPY","LEYB",...
    "NEGB", "NEGP","NEGY","NEPB","NEPY","NEYB",...
    "AFGB", "AFGP","AFGY","AFPB","AFPY","AFYB",...
    "CFGB", "CFGP","CFGY","CFPB","CFPY","CFYB",...
    "IFGB", "IFGP","IFGY","IFPB","IFPY","IFYB",...
    "LFGB", "LFGP","LFGY","LFPB","LFPY","LFYB",...
    "NFGB", "NFGP","NFGY","NFPB","NFPY","NFYB",...
    "AKGB", "AKGP","AKGY","AKPB","AKPY","AKYB",...
    "CKGB", "CKGP","CKGY","CKPB","CKPY","CKYB",...
    "IKGB", "IKGP","IKGY","IKPB","IKPY","IKYB",...
    "LKGB", "LKGP","LKGY","LKPB","LKPY","LKYB",...
    "NKGB", "NKGP","NKGY","NKPB","NKPY","NKYB",...
    "ATGB", "ATGP","ATGY","ATPB","ATPY","ATYB",...
    "CTGB", "CTGP","CTGY","CTPB","CTPY","CTYB",...
    "ITGB", "ITGP","ITGY","ITPB","ITPY","ITYB",...
    "LTGB", "LTGP","LTGY","LTPB","LTPY","LTYB",...
    "NTGB", "NTGP","NTGY","NTPB","NTPY","NTYB"];

frequencies = 2:16;
frequencyBands = [1,2,3,7,11,17,23,31,43,61,89,127,179,251,349];
freqLen = length(frequencies);

titleLen = length(titles);

% Allocate space for impedance data
impedance = zeros(titleLen, freqLen);

for i = 1:titleLen
    for j = 1:freqLen
        freq = frequencies(j);
        imp = impCal(1, freq, titles(i));
        impedance(i,j) = mean(imp); % directly use mean impedance
        writematrix(imp, strcat(titles(i),'.csv'));
    end
end

% Save impedance results
imp_table = array2table(impedance, 'VariableNames', string(frequencyBands), 'RowNames', titles);
writetable(imp_table, 'Impedance_results.csv', 'WriteRowNames', true);

% Define setups
setup_names = ["C", "E", "F", "K", "T"];
setup_indices = [1:30; 31:60; 61:90; 91:120; 121:150];

% Calculate mean and std of impedance per setup
imp_mean = zeros(5, freqLen);
imp_std = zeros(5, freqLen);

for s = 1:5
    imp_mean(s,:) = mean(impedance(setup_indices(s,:), :), 1);
    imp_std(s,:) = std(impedance(setup_indices(s,:), :), 1);
end

% Save mean & std impedance results
imp_mean_table = array2table(imp_mean, 'VariableNames', string(frequencyBands), 'RowNames', setup_names);
imp_std_table = array2table(imp_std, 'VariableNames', string(frequencyBands), 'RowNames', setup_names);
writetable(imp_mean_table, 'Impedance_mean.csv', 'WriteRowNames', true);
writetable(imp_std_table, 'Impedance_std.csv', 'WriteRowNames', true);

% Plot raw impedances with error bars
figure;
hold on;
colors = lines(5);

for s = 1:5
    errorbar(1:freqLen, imp_mean(s,:), imp_std(s,:), '-o',...
        'Color', colors(s,:), 'LineWidth', 1.5, 'MarkerSize', 6);
end

% Axis formatting
xticks(1:freqLen);
xticklabels(string(frequencyBands));
xlabel('Frequency Band (Hz)');
ylabel('Resistance (\Omega)');
title('Raw Resistance vs Frequency Band');
legend(setup_names, 'Location', 'best');
grid on;
hold off;

% --- Supporting Functions ---
function dd = impCal(chNUM,fr1,tit)
    data_temp = readmatrix(strcat(tit,'.txt'), 'Delimiter', '\t', 'ConsecutiveDelimitersRule', 'join');
    data_temp(any(isnan(data_temp),2),:) = [];

    re1 = data_temp(:, fr1);
    im1 = data_temp(:, fr1 + 15);
    mag1 = sqrt(re1.^2 + im1.^2);

    ch = zeros(size(mag1(1:chNUM:end,1),1), size(mag1(1:chNUM:end,1),2), chNUM);
    for i = 1:chNUM
        ch(:,:,i) = movmean(mag1(i:chNUM:end,1), 5);
    end
    dd = squeeze(ch);
end
