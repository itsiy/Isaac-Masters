close all;
clear;

%% Setup
titles = ["CCGY", "CCGB", "CCGP", "CCPY", "CCPB", "CCYB", ...
          "CFGY", "CFGB", "CFGP", "CFPY", "CFPB", "CFYB", ...
          "CKGY", "CKGB", "CKGP", "CKPY", "CKPB", "CKYB", ...
          "CTGY", "CTGB", "CTGP", "CTPY", "CTPB", "CTYB", ...
          "CEGY", "CEGB", "CEGP", "CEPY", "CEPB", "CEYB"];
titleLen = length(titles);
varNumber = 5;
trialsPerVar = titleLen / varNumber;
setup_names = extractBetween(titles(1:trialsPerVar:end), 2, 2);

meanPerDesign = zeros(15, varNumber);
stdPerDesign = zeros(15, varNumber);
perDesignImpedance = cell(1, varNumber);
allTrialImpedanceGlobal = {};

%% Main Loop
for design = 1:varNumber
    perTrialImpedance = zeros(15, trialsPerVar);
    f = waitbar(0, sprintf('Processing Design %d/%d', design, varNumber));

    for trial = 1:trialsPerVar
        idx = trial + (design - 1) * trialsPerVar;
        waitbar(trial/trialsPerVar, f, sprintf('Trial %d/%d', trial, trialsPerVar));
        convertCSV(titles(idx));
        impedance = getMeanImpedance(summariseCSV(titles(idx)));
        perTrialImpedance(:, trial) = impedance;
        allTrialImpedanceGlobal{end+1} = impedance;
    end
    close(f);

    perDesignImpedance{design} = perTrialImpedance;
    meanPerDesign(:, design) = mean(perTrialImpedance, 2);
    stdPerDesign(:, design) = std(perTrialImpedance, 0, 2);
end

%% Global Normalisation and Save Per-Trial Files
allTrials = cell2mat(allTrialImpedanceGlobal')';
globalMin = min(allTrials(:));
globalMax = max(allTrials(:));
rangeGlobal = globalMax - globalMin;

counter = 0;
for design = 1:varNumber
    for trial = 1:trialsPerVar
        counter = counter + 1;
        normTrial = (allTrialImpedanceGlobal{counter} - globalMin) / rangeGlobal;
        T = table((1:15)', normTrial, 'VariableNames', {'FrequencyIndex', 'NormalisedImpedance'});
        writetable(T, sprintf('%s n.csv', titles((design - 1) * trialsPerVar + trial)));
    end
end

%% Normalise Mean and Std for Summary Plot
normMeanPerDesign = (meanPerDesign - globalMin) / rangeGlobal;
normStdPerDesign = (stdPerDesign - globalMin) / rangeGlobal;

plotImpedance(normMeanPerDesign, normStdPerDesign, varNumber, setup_names);
saveas(gcf, 'N_Impedance_Comparison.png');
compareSetups(perDesignImpedance, setup_names);

%% Save Normalised Mean and Std Dev to CSV
csvHeader = ["FrequencyIndex", setup_names{:}];
meanTable = array2table([(1:15)' normMeanPerDesign], 'VariableNames', csvHeader);
stdTable  = array2table([(1:15)' normStdPerDesign],  'VariableNames', csvHeader);
writetable(meanTable, 'N_Normalised_Mean_Impedance.csv');
writetable(stdTable,  'N_Normalised_Std_Impedance.csv');

%% Helper Functions
function data = convertCSV(title)
    raw = readmatrix(strcat(title, ".txt"), "Delimiter", "\t", "NumHeaderLines", 15);
    raw = raw(1:2:end, 2:end);
    targetLen = 200;
    currentLen = size(raw, 1);
    if currentLen > targetLen
        raw = raw(1:targetLen, :);
    elseif currentLen < targetLen
        padding = repmat(raw(end, :), targetLen - currentLen, 1);
        raw = [raw; padding];
    end
    writematrix(raw, strcat(title, ".csv"));
end

function smoothed = smoothColumns(raw, windowSize)
    smoothed = raw;
    for col = 1:size(raw, 2)
        smoothed(:, col) = movmean(raw(:, col), windowSize);
    end
end

function summary = summariseCSV(title)
    raw = readmatrix(strcat(title, ".csv"));
    raw = smoothColumns(raw, 20);
    summary = zeros(15, 2);
    for i = 1:15
        realZ = raw(:, i);
        imagZ = raw(:, i + 15);
        Zmag = sqrt(realZ.^2 + imagZ.^2);
        summary(i, :) = [mean(Zmag), std(Zmag)];
    end
end

function meanImpedance = getMeanImpedance(summary)
    meanImpedance = summary(:, 1);
end

function plotImpedance(meanVals, stdVals, varNumber, setup_names)
    fIdx = 1:15;
    colors = lines(varNumber);
    figure; hold on;
    for i = 1:varNumber
        errorbar(fIdx, meanVals(:, i), stdVals(:, i), '-o', ...
            'Color', colors(i,:), 'LineWidth', 1.5, ...
            'DisplayName', setup_names{i});
    end
    xlabel('Frequency Index'); ylabel('Normalised Impedance (0-1)');
    title('Mean Impedance per Design \pm Std Dev');
    legend('Location', 'best'); grid on;
    hold off;
end

function compareSetups(perDesignImpedance, setup_names)
    fprintf('Impedance Significance Testing: ANOVA per Frequency\n\n');
    for freqIdx = 1:15
        allData = [];
        groupLabels = [];
        for design = 1:numel(perDesignImpedance)
            if setup_names(design) == "E", continue; end
            impAtFreq = perDesignImpedance{design}(freqIdx, :);
            allData = [allData; impAtFreq(:)];
            groupLabels = [groupLabels; repmat(setup_names(design), length(impAtFreq), 1)];
        end
        [p, tbl, stats] = anova1(allData, groupLabels, 'off');
        SS_between = cell2mat(tbl(2,2));
        SS_total = cell2mat(tbl(4,2));
        etaSquared = SS_between / SS_total;
        if p < 0.05
            result = multcompare(stats, 'Display', 'off');
            sigPairs = result(result(:,6) < 0.05, :);
            fprintf('  Significant Differences Between:\n');
            for r = 1:size(sigPairs, 1)
                g1 = stats.gnames{sigPairs(r, 1)};
                g2 = stats.gnames{sigPairs(r, 2)};
                diff = sigPairs(r, 4);
                fprintf('    %s vs %s (mean diff = %.4f)\n', g1, g2, diff);
            end
            fprintf('Freq %2d: Significant (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        else
            fprintf('Freq %2d: No significant difference (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        end
    end
end