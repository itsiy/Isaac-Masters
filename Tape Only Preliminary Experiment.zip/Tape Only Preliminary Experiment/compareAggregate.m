close all;
clear;

%% Settings
ENABLE_OUTLIER_DETECTION = true;
EXCLUDE_OUTLIER_DATA = true;
OUTLIER_METHOD = "std";
STD_MULTIPLIER = 2;

%% Setup
titles = [...  % list of 150+ titles
    "ACGY n", "ACGB n", "ACGP n", "ACPY n", "ACPB n", "ACYB n", ...
    "CCGY n", "CCGB n", "CCGP n", "CCPY n", "CCPB n", "CCYB n", ...
    "ICGY n", "ICGB n", "ICGP n", "ICPY n", "ICPB n", "ICYB n", ...
    "NCGY n", "NCGB n", "NCGP n", "NCPY n", "NCPB n", "NCYB n", ...
    "LCGY n", "LCGB n", "LCGP n", "LCPY n", "LCPB n", "LCYB n", ...
    "AFGY n", "AFGB n", "AFGP n", "AFPY n", "AFPB n", "AFYB n", ...
    "CFGY n", "CFGB n", "CFGP n", "CFPY n", "CFPB n", "CFYB n", ...
    "IFGY n", "IFGB n", "IFGP n", "IFPY n", "IFPB n", "IFYB n", ...
    "NFGY n", "NFGB n", "NFGP n", "NFPY n", "NFPB n", "NFYB n", ...
    "LFGY n", "LFGB n", "LFGP n", "LFPY n", "LFPB n", "LFYB n", ...
    "AKGY n", "AKGB n", "AKGP n", "AKPY n", "AKPB n", "AKYB n", ...
    "CKGY n", "CKGB n", "CKGP n", "CKPY n", "CKPB n", "CKYB n", ...
    "IKGY n", "IKGB n", "IKGP n", "IKPY n", "IKPB n", "IKYB n", ...
    "NKGY n", "NKGB n", "NKGP n", "NKPY n", "NKPB n", "NKYB n", ...
    "LKGY n", "LKGB n", "LKGP n", "LKPY n", "LKPB n", "LKYB n", ...
    "ATGY n", "ATGB n", "ATGP n", "ATPY n", "ATPB n", "ATYB n", ...
    "CTGY n", "CTGB n", "CTGP n", "CTPY n", "CTPB n", "CTYB n", ...
    "ITGY n", "ITGB n", "ITGP n", "ITPY n", "ITPB n", "ITYB n", ...
    "NTGY n", "NTGB n", "NTGP n", "NTPY n", "NTPB n", "NTYB n", ...
    "LTGY n", "LTGB n", "LTGP n", "LTPY n", "LTPB n", "LTYB n", ...
    "AEGY n", "AEGB n", "AEGP n", "AEPY n", "AEPB n", "AEYB n", ...
    "CEGY n", "CEGB n", "CEGP n", "CEPY n", "CEPB n", "CEYB n", ...
    "IEGY n", "IEGB n", "IEGP n", "IEPY n", "IEPB n", "IEYB n", ...
    "NEGY n", "NEGB n", "NEGP n", "NEPY n", "NEPB n", "NEYB n", ...
    "LEGY n", "LEGB n", "LEGP n", "LEPY n", "LEPB n", "LEYB n"];

titleLen = length(titles);
varNumber = 5;
trialsPerVar = titleLen / varNumber;
setup_names = extractBetween(titles(1:trialsPerVar:end), 2, 2);

meanPerDesign = zeros(15, varNumber);
stdPerDesign = zeros(15, varNumber);

%% Main Loop
for design = 1:varNumber
    perTrialImpedance = zeros(15, trialsPerVar);
    f = waitbar(0, sprintf('Processing Design %d/%d', design, varNumber));

    for trial = 1:trialsPerVar
        idx = trial + (design - 1) * trialsPerVar;
        waitbar(trial/trialsPerVar, f, sprintf('Trial %d/%d', trial, trialsPerVar));
        data = readmatrix(strcat(titles(idx), ".csv"));
        perTrialImpedance(:, trial) = data(:, 2);
    end
    close(f);

    % Outlier filtering
    filteredImpedance = perTrialImpedance;
    if ENABLE_OUTLIER_DETECTION && EXCLUDE_OUTLIER_DATA
        for freqIdx = 1:15
            freqData = perTrialImpedance(freqIdx, :);
            mu = mean(freqData);
            sigma = std(freqData);
            if OUTLIER_METHOD == "std"
                mask = abs(freqData - mu) > STD_MULTIPLIER * sigma;
                filteredImpedance(freqIdx, mask) = NaN;
            end
        end
    end

    plotAllTrials(filteredImpedance, setup_names{design});
    saveas(gcf, sprintf('TrialImpedance_Design_%s.png', setup_names{design}));

    perDesignImpedance{design} = filteredImpedance;
    meanPerDesign(:, design) = mean(filteredImpedance, 2, 'omitnan');
    stdPerDesign(:, design) = std(filteredImpedance, 0, 2, 'omitnan');
end

plotImpedance(meanPerDesign, stdPerDesign, varNumber, setup_names);
saveas(gcf, 'Impedance_Comparison.png');
compareSetups(perDesignImpedance, setup_names);

%% Helper Functions
function plotAllTrials(data, setup_name)
    fIdx = 1:15;
    n = size(data, 2);
    cmap = turbo(n);
    figure; hold on;
    for i = 1:n
        plot(fIdx, data(:,i), '-', 'Color', cmap(i,:), 'LineWidth', 1.2);
    end
    xlabel('Frequency Index'); ylabel('Normalised Impedance');
    title(['Impedance per Trial (', setup_name, ' Setup)']);
    legend("Trial " + string(1:n), 'Location', 'eastoutside'); grid on;
    hold off;
end

function plotImpedance(meanVals, stdVals, varNumber, setup_names)
    fIdx = 1:15;
    colors = lines(varNumber);
    figure; hold on;
    for i = 1:varNumber
        errorbar(fIdx, meanVals(:, i), stdVals(:, i), '-o', ...
            'Color', colors(i,:), 'LineWidth', 1.5, ...
            'DisplayName', setup_names{i});
    end
    xlabel('Frequency Index'); ylabel('Normalised Impedance');
    title('Mean Impedance per Design ± Std Dev');
    legend('Location', 'best'); grid on;
    hold off;
end

function compareSetups(perDesignImpedance, setup_names)
    fprintf('Impedance Significance Testing: ANOVA per Frequency\n\n');
    for freqIdx = 1:15
        allData = [];
        groupLabels = [];
        for design = 1:numel(perDesignImpedance)
            if setup_names(design) == "E", continue; end
            impAtFreq = perDesignImpedance{design}(freqIdx, :);
            allData = [allData; impAtFreq(:)];
            groupLabels = [groupLabels; repmat(setup_names(design), length(impAtFreq), 1)];
        end
        [p, tbl, stats] = anova1(allData, groupLabels, 'off');
        SS_between = cell2mat(tbl(2,2));
        SS_total = cell2mat(tbl(4,2));
        etaSquared = SS_between / SS_total;
        if p < 0.05
            result = multcompare(stats, 'Display', 'off');
            sigPairs = result(result(:,6) < 0.05, :);
            fprintf('  Significant Differences Between:\n');
            for r = 1:size(sigPairs, 1)
                g1 = stats.gnames{sigPairs(r, 1)};
                g2 = stats.gnames{sigPairs(r, 2)};
                diff = sigPairs(r, 4);
                fprintf('    %s vs %s (mean diff = %.4f)\n', g1, g2, diff);
            end
            fprintf('Freq %2d: Significant (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        else
            fprintf('Freq %2d: No significant difference (p = %.4f), eta^2 = %.4f\n', freqIdx, p, etaSquared);
        end
    end
end
